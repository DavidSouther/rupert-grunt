angular.module('rupert-app', [
  'rupert-app.head-controller'
]);
