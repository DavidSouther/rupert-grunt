/* global describe: false, it: false */
describe('A Feature', function(){
  it('runs tests', function(){
    var foo = true;
    foo.should.equal(true);
  });
});
