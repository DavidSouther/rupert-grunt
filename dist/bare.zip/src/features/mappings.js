module.exports = {
  'ubiquitous language component': '#selector .forComponent',
};
